
#include "freetime.h"

FreeTime::FreeTime()
{

}

FreeTime::FreeTime(QString _time)
    :time(_time)
{

}


FreeTime::FreeTime(QString _time, int _col)
    :time(_time), col(_col)
{

}
