#include "versionwindow.h"
#include "ui_versionwindow.h"

VersionWindow::VersionWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VersionWindow)
{
    ui->setupUi(this);
    ui->radioButton_2->setChecked(true);
    ui->textEdit->setEnabled(false);
    ui->textEdit_2->setReadOnly(true);
    ui->radioButton->setEnabled(false);

}

VersionWindow::~VersionWindow()
{
    delete ui;
}
