
#ifndef FREETIME_H
#define FREETIME_H

#include "member.h"
#include <vector>
using std::vector;

class FreeTime
{
public:
    FreeTime();
    FreeTime(QString _time);
    FreeTime(QString _time, int _col);
    vector<Member*>members;
    QString time;
    int col;
};

#endif // FREETIME_H
