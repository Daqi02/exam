
#ifndef CSVFILE_H
#define CSVFILE_H

#include <QFile>
#include <vector>
#include "member.h"
#include "freetime.h"

#define FIELDNUM 4

using std::vector;

class csvFile
{
public:
    csvFile(int num[3]);
    csvFile();
    bool openFile(const QString& path); //打开文件
    void initMember();                  //初始化成员
    int* checkField();                  //检查字段存在性
    void allocationMember(int roomnum[], bool schools[], int mean[]);            //分配成员
    bool save();                        //保存排班表

    QString utf8toUnicode(QByteArray utf8);

public:
    vector<Member*> getMembers();
    vector<FreeTime*> getFreeTimes();
    vector<FreeTime*> getAllocation(int i);
    void getFieldSeq();                 //获得文件字段
    int *getFiled();
    void setRooNum(int num[]);

private:
    int roomNum[3];
    vector<Member*>members;
    vector<FreeTime*>freetimes; //用来存放每个时间段有空的人
    vector<FreeTime*>allocation[3]; //用来存放排班后的某一时间段某一场地的人    0五山 1大学城 2国际
    QFile* file;             //文件
    QStringList row;        //存储所有行下信息
    int field[FIELDNUM] = { -1 };

};

#endif // CSVFILE_H
