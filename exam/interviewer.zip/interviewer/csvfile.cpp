/**
 *
 * 进行排班
 * 2023/8/9 修改第二次
 *
 *
 *
 **/

#include "csvfile.h"
#include <QDebug>
#include <QString>
#include <QTextCodec>
#include <QDateTime>
#include <QCoreApplication>
#include <QDir>
#define NAME 0
#define SCHOOL 1
#define FREETIME 2
#define ZHIYUAN 3

csvFile::csvFile(int num[3])
{
    roomNum[0] = num[0];
    roomNum[1] = num[1];
    roomNum[2] = num[2];
}

csvFile::csvFile()
{

}

bool csvFile::openFile(const QString &path)
{
    file = new QFile(path);
    if(!file->open(QIODevice::ReadOnly | QIODevice::Text))
    {
        return false;
    }
    return true;
}

void csvFile::getFieldSeq()
{
    QTextStream * read = new QTextStream(file);
    row = read->readAll().split("\n",Qt::SkipEmptyParts);   //每行以‘\n’隔开

    //读取表头信息，找到姓名、空闲时间
    QStringList strLine = row.at(0).split(",");    //每个字段以','隔开
    int col = strLine.count();
    QTextCodec *codec = QTextCodec::codecForName("GBK");
    for(int i = 0; i < col; ++i)
    {
        QString aa = strLine.at(i);
        qDebug() << utf8toUnicode(aa.toLocal8Bit());
        if(strLine.at(i).contains("姓名") || strLine.at(i).contains("名字") || strLine.at(i).contains("名"))  //检查是否含有名字关键字
        {
            field[NAME] = i;
        }
        else if(strLine.at(i).contains("空闲") || strLine.at(i).contains("时间") || strLine.at(i).contains("时段"))   //检查是否含有时间关键字
        {
            if(strLine.at(i).contains("没空") || strLine.at(i).contains("不行"))  //检查是否含有没空关键字，如果有则不记录
                continue;
            field[FREETIME] = i;
            qDebug() << "DEBUG1: " << strLine.at(i);
            freetimes.push_back(new FreeTime(strLine.at(i), i));
        }
        else if(strLine.at(i).contains("校区") && !strLine.at(i).contains("支援"))   //检查校区
        {
            field[SCHOOL] = i;
        }
        else if(strLine.at(i).contains("支援"))
        {
            field[ZHIYUAN] = i;
        }
    }
    //关闭文件
    file->close();
    delete file;
}

void csvFile::initMember()
{
    int freenum = freetimes.size();
    for(int i = 1; i < row.count(); ++i)
    {
        qDebug() << i << "/" << row.count();
        QStringList strLine = row.at(i).split(",");            //一行中的单元格以，区分
        members.push_back(new Member(strLine.at(field[NAME]), strLine.at(field[SCHOOL]), i-1));         //初始化成员
        qDebug() << strLine.at(field[NAME]);
        qDebug() << strLine.at(field[SCHOOL]);

        //检查空闲时间段
        for(int j = 0; j < freenum; j++)
        {
            if(!strLine.at(freetimes[j]->col).isEmpty())
            {
                freetimes[j]->members.push_back(members[i - 1]);
            }
        }
    }
}

/**
 * @brief csvFile::allocation[i]Member
 * @param roomnum 场地数量
 * @param schools 开设活动的校区
 *                下标 * 0五山 1大学城 2国际
 *                数值 * 0不开设 1开设
 * @param mean 最大一场人数
 */
void csvFile::allocationMember(int roomnum[], bool schools[], int mean[])
{
    //信息的处理
    QString schoolname[3] = {"五山校区", "大学城校区", "国际校区"};

    //进行分配
    Member* best = NULL;   //最好的人选
    for(int i = 0; i < 3; ++i)        //对于每个校区
    {
        if(!schools[i])    //检查是否开设
            continue;

        //分配场地
        QString room[roomnum[i]];
        for(int x = 0; x < roomnum[i]; ++x)
        {
            room[x] = QString("场地%1").arg(x + 1);
        }

        //qDebug() << "debug0";

        for(int j = 0; j < (int)freetimes.size(); ++j)    //对于每个时间段
        {
            for(int k = 0; k < roomnum[i]; k++)        //对于每个场地
            {
                allocation[i].push_back(new FreeTime(schoolname[i] + "-" + freetimes[j]->time + "-" + room[k]));   //增加一个时间段
            }

            ///用来记录是否分配
            bool isfree[100] = { true };       //这个人是否空闲
            for(int z = 0; z < 100; ++z) isfree[z] = true;
            //for(int z = 0; z < (int)members.size(); ++z)  qDebug() << isfree[i];

            int order = 0;      //当前应该轮到哪个教室

            /** 主要逻辑*********************************************/
            /** ****************************************************/
            ///分配该时间段里的人
            //时间段空闲人数
            int membernum = freetimes[j]->members.size();
            //最小循环次数: 时间段中空闲人数和所需要人数的最小值
            int num = membernum > mean[i]*roomnum[i] ? mean[i]*roomnum[i] : membernum;
            qDebug() << num;
            for(int m = 0; m < num; ++m)
            {
                qDebug() << "第" << m << "次循环";
                //qDebug() << "对于每个时间段";

                QString s;
                for(int n = 0; n < membernum; ++n) s.append(QString("%1").arg(isfree[freetimes[j]->members[n]->getId()]));
                qDebug() << s;

                for(int n = 0; n < membernum; ++n)    //寻找对于每个时间段work最小且本校区且空闲的人
                {
                    if(freetimes[j]->members[n]->getSchool().contains(schoolname[i]))       //如果是这个校区的人且空闲
                    {
                        if(!isfree[freetimes[j]->members[n]->getId()])
                            continue;
                        if(best == NULL || freetimes[j]->members[n]->getWork() < best->getWork())   //如果工作量是当前最小
                        {
                            best = freetimes[j]->members[n];
                            isfree[best->getId()] = false;
                        }
                    }
                }

                //如果最后没有人选
                //进行下一个时间段的排班
                if(best == NULL) break;

                qDebug() << "人选id: " << best->getId();
                qDebug() << "最好的人选: " << best->getName() << best->getSchool();
                //判断当前场次是否满人
                //满人则跳过
                while(1)
                {
                    if((int)allocation[i][allocation[i].size() - roomnum[i] + order]->members.size() <= mean[i])
                    {
                        qDebug() << allocation[i][allocation[i].size() - roomnum[i] + order]->time;
                        allocation[i][allocation[i].size() - roomnum[i] + order]->members.push_back(best);
                        best->addWork();
                        order = (order + 1) % roomnum[i];
                        best = NULL;
                        break;
                    }
                    order = (order + 1) % roomnum[i];
                }
                best = NULL;
            }
        }
    }
    delete best;
}

bool csvFile::save()
{

}

QString csvFile::utf8toUnicode(QByteArray utf8)
{
    QTextCodec::ConverterState state;
    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QString gbk = codec->toUnicode(utf8.constData(), utf8.size(), &state);
    if (state.invalidChars > 0)
    {
        gbk = QTextCodec::codecForName("GBK")->toUnicode(utf8);
    }
    return gbk;
}

vector<Member*> csvFile::getMembers()
{
    return members;
}

vector<FreeTime*> csvFile::getFreeTimes()
{
    return freetimes;
}

vector<FreeTime *> csvFile::getAllocation(int i)
{
    return allocation[i];
}

int *csvFile::getFiled()
{
    return field;
}

void csvFile::setRooNum(int num[])
{
    for(int i = 0; i < 3; ++i)
    {
        roomNum[i] = num[i];
    }
}

