
#ifndef MEMBER_H
#define MEMBER_H

#include <QString>


class Member
{
public:
    Member();
    Member(const QString& _name);
    Member(const QString& _name, const QString& _school);
    Member(const QString& _name, const QString& _school, int _id);
    int getId();
    int getWork();
    void addWork();
    QString getName();
    QString getSchool();

private:
    int id;
    int work = 0;
    QString name;
    QString school;
};

#endif // MEMBER_H
