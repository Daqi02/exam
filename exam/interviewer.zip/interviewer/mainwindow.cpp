
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "versionwindow.h"
#include "helpwindow.h"
#include "questionwindow.h"
#include <QFileDialog>
#include <QString>
#include <QMessageBox>
#include <QDateTime>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    csv = new csvFile();
    this->setWindowTitle("ss");
    setWindowTitle("8+招生宣传协会内部专用");
    ui->setupUi(this);

    //设置路径文本框不可编辑
    ui->pathText->setReadOnly(true);
    ui->pathLineEdit->setReadOnly(true);
    //设置生成按钮不可点击
    ui->genBT->setEnabled(false);
    ui->saveBT->setEnabled(false);
    //设置不可修改数量
    ui->daxuecheng->setEnabled(false);
    ui->wushan->setEnabled(false);
    ui->guoji->setEnabled(false);
    ui->ackBT->setEnabled(false);
    ui->roomNumText->setEnabled(false);
    ui->timeNum->setEnabled(false);
    ui->maxMember->setEnabled(false);
    ui->wushanmaxmember->setEnabled(false);
    ui->wushanroomnum->setEnabled(false);
    ui->guojimaxmember->setEnabled(false);
    ui->guojiroomnum->setEnabled(false);
    //设置复选框默认值
    ui->seniorCheckBox_2->setEnabled(false);
    ui->sexCheckBox->setEnabled(false);
    ui->zhiyuanCheckBox->setEnabled(false);
    ui->meanCheckBox->setEnabled(false);
    ui->meanCheckBox->setChecked(true);

    ui->pathText->append("【欢迎使用】<font color=\"#0d00ff\">华南理工大学</font><font color=\"#632e2e\">8+招生宣传协会人力资源部</font>排班用~");
    ui->pathText->append("<font color=\"#5c5c5c\">------------>为方便使用，前一步完成后再允许点击下一步的按钮，详细请点击上方的帮助查看~");
    ui->pathText->append("<font color=\"#5c5c5c\">---------->1.添加csv/txt文件</font>");
    ui->pathText->append("<font color=\"#5c5c5c\">---------->2.设置数量</font>");
    ui->pathText->append("<font color=\"#5c5c5c\">---------->3.生成排班表</font>");
    ui->pathText->append("<font color=\"#8c8c8c\">\\     @人力ykq~\\</font>");
    ui->pathText->append("<font color=\"#8c8c8c\">\\Version v23.1.0\\</font>");
    ui->pathText->append("<font color=\"#8c8c8c\">\\Last revision 2023.7.25 v23.1.0\\</font>");
    ui->pathText->append("<font color=\"#8c8c8c\">\\Revision content 基本排班功能\\</font>");
}

MainWindow::~MainWindow()
{
    delete csv;
    delete ui;
}

void MainWindow::on_csvBT_clicked()
{
    QString filefull;
    QFileInfo fi;
    QFileDialog* filedialog = new QFileDialog;

    //打开文件对话窗口，选择文件
    filefull = filedialog->getOpenFileName(this,tr("选择问卷结果文件"),".../",tr("问卷结果(*.txt; *.csv)"));

    //获取文件信息
    fi = QFileInfo(filefull);

    //取出携带文件名称的文件绝对路径
    QString temp = fi.filePath();
    delete filedialog;

    if(temp.isEmpty())
    {
        ui->pathText->append(QString("<font color=\"#0000ff\">【文件路径】</font>").append("<font color=\"#ff0000\">未选择文件</font>"));
        return;
    }
    filepath = temp;

    //UI
    ui->pathLineEdit->setText(QString("文件路径: ") + filepath);
    ui->pathText->append("<font color=\"#0000ff\">" + QString(filepath).prepend("【文件路径】") + "</font>");
    ui->pathText->setFontWeight(QFont::Normal);
    ui->ackBT->setEnabled(true);
    ui->daxuecheng->setEnabled(true);
    ui->wushan->setEnabled(true);
    ui->guoji->setEnabled(true);
}

/**
 * @brief MainWindow::on_ackBT_clicked
 *
 * 点击确认数量按钮
 */
void MainWindow::on_ackBT_clicked()
{
    int count = 0;
    if(ui->wushan->checkState() == Qt::Checked)
    {
        time = ui->timeNum->value();
        roomNum[0] = ui->wushanroomnum->value();
        maxMemberNum[0] = ui->wushanmaxmember->value();
        if(!checkNum(0)) return;
        count++;
    }
    if(ui->daxuecheng->checkState() == Qt::Checked)
    {
        roomNum[1] = ui->roomNumText->value();
        time = ui->timeNum->value();
        maxMemberNum[1] = ui->maxMember->value();
        if(!checkNum(1)) return;
        count++;
    }
    if(ui->guoji->checkState() == Qt::Checked)
    {
        time = ui->timeNum->value();
        roomNum[2] = ui->guojiroomnum->value();
        maxMemberNum[2] = ui->guojimaxmember->value();
        if(!checkNum(2)) return;
        count++;
    }
    QMessageBox* tips = new QMessageBox(this);
    tips->setWindowTitle("提示~");
    if(count == 0)
    {
        tips->setText("设置失败~需选择1个及以上校区~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">" + QString("【失败提示】需选择1个及以上校区~") + "</font>");
        return;
    }
    tips->setText("设置成功~");
    tips->show();
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【成功提示】设置成功~") + "</font>");
    ui->ackBT->setText("修改数量");
    ui->genBT->setEnabled(true);
}

bool MainWindow::checkNum(int i)
{
    QMessageBox* tips = new QMessageBox(this);
    tips->setWindowTitle("提示~");
    //判断输入的是否为整数
    if(roomNum[i] <= 0)
    {
        tips->setText("请输入非负整数的场地数量~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【数量错误】场地数量不能为0，请输入非负整数~") + "</font>");
        return 0;
    }
    if(time <= 0)
    {
        tips->setText("请输入非负整数的时间段数量~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【数量错误】时间段数量不能为0，请输入非负整数~") + "</font>");
        return 0;
    }
    if(maxMemberNum[i] <= 0)
    {
        tips->setText("请输入非负整数的每个教室/场地最大人数~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【数量错误】人数不能为0，请输入非负整数~") + "</font>");
        return 0;
    }
    return 1;
}

void MainWindow::on_genBT_clicked()
{
    //读取其他参数
    //开设活动的校区
    schools[0] = ui->wushan->checkState()?1:0;
    schools[1] = ui->daxuecheng->checkState()?1:0;
    schools[2] = ui->guoji->checkState()?1:0;

    QMessageBox* tips = new QMessageBox(this);
    tips->setWindowTitle("提示~");

    //判断是否选择了正确格式的文件
    if(filepath.isEmpty())
    {
        tips->setText("未选择文件~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【文件错误】未选择文件~") + + "</font>");
        return;
    }
    else if(!filepath.endsWith(".csv") && !filepath.endsWith(".txt"))
    {
        tips->setText("文件格式错误，选择csv或txt格式文件~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【文件错误】文件格式错误，选择csv或txt格式文件~") + + "</font>");
        return;
    }

    //判断是否为csv或txt文件
    csvFile* newcsv = csv;
    csv = new csvFile();
    delete newcsv;
    csv->setRooNum(roomNum);
    if(filepath.endsWith(".csv") || filepath.endsWith(".txt"))
    {
        if(csv->openFile(filepath))
        {
            tips->setText("创建成功~");
            tips->show();
        }
        else
        {
            tips->setText("打开文件失败~重新尝试~");
            tips->show();
            ui->pathText->append("<font color=\"#ff0000\">" + tr("【文件错误】文件打开失败") + "</font>");
            return;
        }
    }

    //获取字段序号
    csv->getFieldSeq();

    //检查字段是否完整
    if(csv->getFiled()[0] == -1)
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【字段错误】请检查“姓名”字段是否包含“姓名”、“名字”或“名”~") + "</font>");
        return;
    }
    else
        ui->pathText->append("<font color=\"#2d6b27\">" + QString("【成功提示】成功读取姓名~") + "</font>");
    if(csv->getFiled()[1] == -1)
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【字段错误】请检查“校区”字段是否包含“姓名”、“名字”或“名”~") + "</font>");
        return;
    }
    else
        ui->pathText->append("<font color=\"#2d6b27\">" + QString("【成功提示】成功读取校区~") + "</font>");
    if(csv->getFiled()[2] == -1)
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【字段错误】请检查“空闲时间”字段是否包含“姓名”、“名字”或“名”~") + "</font>");
        return;
    }
    else
        ui->pathText->append("<font color=\"#2d6b27\">" + QString("【成功提示】成功读取空闲时间~") + "</font>");

    //初始化成员
    csv->initMember();

    //输出成员信息
    ui->pathText->append(" ");
    QString names("<font color=\"#1469c7\">【成员信息】</font>");
    for(int i = csv->getMembers().size() - 1; i >=0 ; --i)
    {
        names.append(csv->getMembers()[i]->getName() + " ");
    }
    ui->pathText->append(names.append(QString("<font color=\"#a09b3f\">[共%1人]").arg(csv->getMembers().size())).append("</font>"));

    //输出时间段信息
    names.clear();
    names.append("<font color=\"#1469c7\">【时间段】</font>");
    ui->pathText->append(" ");
    for(int i = csv->getFreeTimes().size() - 1; i >= 0; --i)
    {
        names.append(csv->getFreeTimes()[i]->time + " ");
    }
    ui->pathText->append(names.append(QString("<font color=\"#a09b3f\">[共%1段]").arg(csv->getFreeTimes().size())).append("</font>"));

    //检查时间段数量是否一致
    if((int)csv->getFreeTimes().size() != time)
    {
        tips->setText("生成中断~");
        tips->show();
        ui->pathText->append("<font color=\"#ff0000\">【信息错误】检查时间段数量是否正确，以及文件表头的信息是否规范~</font>");
        return;
    }

    //输出某一时间段空闲的成员
    ui->pathText->append(" ");
    for(int i = 0; i < time; ++i)
    {
        names.clear();
        names.append("<font color=\"#1469c7\">【" + csv->getFreeTimes()[i]->time + "】</font>");
        int num = (int)csv->getFreeTimes()[i]->members.size();
        for(int j = 0; j < num; ++j)
        {
            names.append(csv->getFreeTimes()[i]->members[j]->getName() + " ");
        }
        ui->pathText->append(names.append(QString("<font color=\"#a09b3f\">[共%1人]").arg(csv->getFreeTimes()[i]->members.size())).append("</font>"));
    }

    //进行分配
    csv->allocationMember(roomNum, schools, maxMemberNum);

    //输出分配后的信息
    ui->pathText->setFontWeight(QFont::Bold);
    ui->pathText->append("");
    ui->pathText->append("---------------------------------------------------");
    ui->pathText->append("---------------------排班结果---------------------");
    ui->pathText->append("---------------------------------------------------");
    //ui->pathText->setFontWeight(QFont::Normal);
    QString schoolsName[3] ={"五山校区", "大学城校区", "国际校区"};
    for(int a = 0; a < 3; ++a)      //对于三个校区
    {
        ui->pathText->setFontWeight(QFont::Bold);
        ui->pathText->append("---------------------------------------------------");
        ui->pathText->append("");
        if(csv->getAllocation(a).size() == 0)   //检查是否开设
        {
            ui->pathText->setTextColor(QColor(255,0,0));
            ui->pathText->append(QString("%1未开设面试~").arg(schoolsName[a]));
            continue;
        }
        else
        {
            ui->pathText->setTextColor(QColor(31,123,143));
            ui->pathText->append(QString("%1面试官安排: ").arg(schoolsName[a]));
        }
        ui->pathText->setTextColor(QColor(0,0,0));
        ui->pathText->setFontWeight(QFont::Normal);

        for(int t = 0; t < time; ++t)
        {
            ui->pathText->append(QString("<font color=\"#0000ff\">【时间段%1】").arg(t+1) + "</font>");
            //ui->pathText->setFontWeight(QFont::Normal);
            for(int i = 0; i < roomNum[a]; ++i)
            {
                ui->pathText->append(csv->getAllocation(a)[i+t*roomNum[a]]->time.remove(schoolsName[a]));
                names.clear();
                for(int j = 0; j < (int)csv->getAllocation(a)[i+t*roomNum[a]]->members.size(); ++j)
                {
                    names.append(csv->getAllocation(a)[i+t*roomNum[a]]->members[j]->getName() + " ");
                }
                ui->pathText->append(names);
            }
        }
    }
    ui->saveBT->setEnabled(true);
    delete tips;
}


void MainWindow::on_clearBT_clicked()
{
    log.append(ui->pathText->toHtml());
    ui->pathText->clear();
    ui->pathText->append("【欢迎使用】<font color=\"#0d00ff\">华南理工大学</font><font color=\"#632e2e\">8+招生宣传协会人力资源部</font>排班用~");
}


void MainWindow::on_exitBT_clicked()
{
    this->close();
}


void MainWindow::on_versionBT_clicked()
{
    VersionWindow* version = new VersionWindow();
    version->show();
}


void MainWindow::on_daxuecheng_stateChanged(int arg1)
{
    if(arg1 == Qt::Checked)
    {
        ui->roomNumText->setEnabled(true);
        ui->timeNum->setEnabled(true);
        ui->maxMember->setEnabled(true);
    }
    else
    {
        ui->maxMember->setEnabled(false);
        ui->roomNumText->setEnabled(false);
        if(ui->guoji->checkState() != Qt::Checked && ui->wushan->checkState() != Qt::Checked)
            ui->timeNum->setEnabled(false);
    }
}


void MainWindow::on_wushan_stateChanged(int arg1)
{
    if(arg1 == Qt::Checked)
    {
        ui->wushanmaxmember->setEnabled(true);
        ui->wushanroomnum->setEnabled(true);
        ui->timeNum->setEnabled(true);
    }
    else
    {
        ui->wushanmaxmember->setEnabled(false);
        ui->wushanroomnum->setEnabled(false);
        if(ui->daxuecheng->checkState() != Qt::Checked && ui->guoji->checkState() != Qt::Checked)
            ui->timeNum->setEnabled(false);
    }
}


void MainWindow::on_guoji_stateChanged(int arg1)
{
    if(arg1 == Qt::Checked)
    {
        ui->timeNum->setEnabled(true);
        ui->guojimaxmember->setEnabled(true);
        ui->guojiroomnum->setEnabled(true);
    }
    else
    {
        ui->guojimaxmember->setEnabled(false);
        ui->guojiroomnum->setEnabled(false);
        if(ui->daxuecheng->checkState() != Qt::Checked && ui->wushan->checkState() != Qt::Checked)
            ui->timeNum->setEnabled(false);
    }
}


void MainWindow::on_helpBT_clicked()
{
    HelpWindow* help = new HelpWindow();
    help->show();
}


void MainWindow::on_problemBT_clicked()
{
    QuestionWindow* question = new QuestionWindow();
    question->show();
}


void MainWindow::on_saveBT_clicked()
{
    QString file_path =  QFileDialog::getSaveFileName(this,tr("保存排班表"),".../","结果文件 (*.csv; *.txt);;all files(*.*)");
    //将返回一个由用户选择的文件名。该文件不一定存在。
    //第一个参数：父对象 第二个参数：设置文件对话框标题 第三个参数：设置打开的默认路径 第四个参数：文件类型过滤器
    qDebug() << "选择的保存路径为: " << file_path;
    if(file_path.isEmpty())
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【操作提示】保存文件操作取消~") + "</font>");
        return;
    }
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【操作提示】保存文件路径为:").append(file_path).append("~") + "</font>");
    QFile file(file_path);
    if(!file.open(QIODevice::WriteOnly))
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【操作提示】无法写入文件，请重试~") + "</font>");
        return;
    }
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【操作提示】正在保存~: ").append(file_path).append("~") + "</font>");

    QString schoolsName[3] ={"五山校区", "大学城校区", "国际校区"};
    for(int a = 0; a < 3; ++a)      //对于三个校区
    {
        file.write(QString(schoolsName[a]).append("\n").toLocal8Bit());
        //检查是否开设
        if(csv->getAllocation(a).size() == 0)
        {
            file.write(QString("无\n").toLocal8Bit());
            file.write("\n");
            continue;
        }

        //分别将每个时间段的人写入文件
        for(int t = 0; t < time; ++t)
        {
            file.write(QString("时间段%1\n").arg(t+1).toLocal8Bit());
            for(int i = 0; i < roomNum[a]; ++i)
            {
                file.write(csv->getAllocation(a)[i+t*roomNum[a]]->time.remove(schoolsName[a]).append(",").toLocal8Bit());
                int num = (int)csv->getAllocation(a)[i+t*roomNum[a]]->members.size();
                //判断是否有人
                if(num == 0)
                {
                    file.write("\n");
                    continue;
                }
                //将安排的人写入文件
                for(int j = 0; j < num; ++j)
                {
                    file.write(csv->getAllocation(a)[i+t*roomNum[a]]->members[j]->getName().toLocal8Bit());
                    if(j != num - 1) file.write(",");
                    else file.write("\n");
                }
            }
        }
        file.write("\n");
    }
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【操作提示】保存成功~: ").append(file_path).append("~") + "</font>");
}


void MainWindow::on_workBT_clicked()
{
    ui->pathText->setFontWeight(QFont::Bold);
    ui->pathText->append(QString("\n\n【工作量信息显示】"));
    ui->pathText->setTextColor(QColor(0,0,0));
    ui->pathText->setFontWeight(QFont::Normal);
    QString names;
    int num = csv->getMembers().size();
    for(int i = 0; i < num; ++i)
    {
        names.append(QString(csv->getMembers()[i]->getName()).append("<font color=\"#2d6b27\">%1场</font>").arg(csv->getMembers()[i]->getWork()));
        if((i % 5 == 0 && i != 0) || i == num - 1)
        {
            ui->pathText->append(names);
            names.clear();
        }
    }
}


void MainWindow::on_saveinfoBT_clicked()
{
    QString file_path =  QFileDialog::getSaveFileName(this,tr("保存信息日志"),".../","信息日志 (*.html; *.txt);;all files(*.*)");
    qDebug() << "选择的保存路径为: " << file_path;
    if(file_path.isEmpty())
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【操作提示】保存文件操作取消~") + "</font>");
        return;
    }
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【操作提示】保存文件路径为:").append(file_path).append("~") + "</font>");
    QFile file(file_path);
    if(!file.open(QIODevice::WriteOnly))
    {
        ui->pathText->append("<font color=\"#ff0000\">" + tr("【操作提示】无法写入文件，请重试~") + "</font>");
        return;
    }
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【操作提示】正在保存~: ").append(file_path).append("~") + "</font>");

    file.write(log.toLocal8Bit());
    file.write(QString(ui->pathText->toHtml()).toLocal8Bit());
    ui->pathText->append("<font color=\"#2d6b27\">" + QString("【操作提示】保存成功~: ").append(file_path).append("~") + "</font>");
}


void MainWindow::on_notallocatedBT_clicked()
{
    ui->pathText->setFontWeight(QFont::Bold);
    ui->pathText->append(QString("\n\n【未安排人员】"));
    ui->pathText->setTextColor(QColor(0,0,0));
    ui->pathText->setFontWeight(QFont::Normal);
    QString names;

    //对于每个时间段分别统计
    for(int j = 0; j < (int)csv->getFreeTimes().size(); ++j)
    {
        //改数组用来判断谁空闲
        bool free[100];
        for(int n = 0; n < 100; ++n) free[n] = true;

        //三个校区一起统计
        for(int i = 0; i < 3; ++i)
        {
            if(!schools[i]) continue;
            int position = j * roomNum[i];
            for(int k = position; k < position + roomNum[i]; ++k)
            {
                qDebug() << "无";
                for(int l = 0; l < (int)csv->getAllocation(i)[k]->members.size(); ++l)
                    free[csv->getAllocation(i)[k]->members[l]->getId()] = false;
            }
        }

        names.append(QString("<font color=\"#1469c7\">【").append(csv->getFreeTimes()[j]->time) + "】</font> ");
        for(int k = 0; k < (int)csv->getFreeTimes()[j]->members.size(); ++k)
        {
            if(free[csv->getFreeTimes()[j]->members[k]->getId()]) names.append(csv->getFreeTimes()[j]->members[k]->getName() + " ");
        }
        ui->pathText->append(names);
        names.clear();
    }
}

