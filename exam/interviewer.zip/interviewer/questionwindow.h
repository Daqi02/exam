#ifndef QUESTIONWINDOW_H
#define QUESTIONWINDOW_H

#include <QWidget>
#include <vector>
#include <QListWidgetItem>

using std::vector;

namespace Ui {
class QuestionWindow;
}

class QuestionWindow : public QWidget
{
    Q_OBJECT

public:
    explicit QuestionWindow(QWidget *parent = nullptr);
    ~QuestionWindow();
    void initanswers();

private slots:
    void on_searchBT_clicked();

    void on_returnBT_clicked();

    void on_listWidget_itemClicked(QListWidgetItem *item);

private:
    Ui::QuestionWindow *ui;
    vector<QString>questions;
    vector<QString>answers;
};

#endif // QUESTIONWINDOW_H
