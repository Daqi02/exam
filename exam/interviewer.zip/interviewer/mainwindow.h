
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include "csvfile.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    bool checkNum(int i);

private slots:
    void on_csvBT_clicked();
    void on_ackBT_clicked();
    void on_genBT_clicked();
    void on_clearBT_clicked();

    void on_exitBT_clicked();

    void on_versionBT_clicked();

    void on_daxuecheng_stateChanged(int arg1);

    void on_wushan_stateChanged(int arg1);

    void on_guoji_stateChanged(int arg1);

    void on_helpBT_clicked();

    void on_problemBT_clicked();

    void on_saveBT_clicked();

    void on_workBT_clicked();

    void on_saveinfoBT_clicked();

    void on_notallocatedBT_clicked();

private:
    Ui::MainWindow *ui;
    QString filepath;
    int roomNum[3];        //场地数量
    int time;           //时间段数量
    int maxMemberNum[3];   //最大人数
    bool schools[3];    //开设的校区 五山、大学城、国际

    csvFile* csv;
    QString log;
};

#endif // MAINWINDOW_H
