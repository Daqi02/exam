
#include "member.h"

Member::Member()
{

}

Member::Member(const QString& _name)
    :name(_name)
{

}

Member::Member(const QString &_name, const QString &_school)
    :name(_name), school(_school)
{

}

Member::Member(const QString &_name, const QString &_school, int _id)
    :id(_id), name(_name), school(_school)
{

}

int Member::getId()
{
    return id;
}

int Member::getWork()
{
    return work;
}

void Member::addWork()
{
    ++work;
}

QString Member::getName()
{
    return name;
}

QString Member::getSchool()
{
    return school;
}

