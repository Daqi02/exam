#include "questionwindow.h"
#include "ui_questionwindow.h"

QuestionWindow::QuestionWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QuestionWindow)
{
    questions.push_back("1.生成排班表显示乱码？");
    questions.push_back("2.生成中断?");
    questions.push_back("3.修改了数量但是还是按照以前的参数生成？");
    questions.push_back("4.保存的html格式的信息日志文件显示乱码？");
    questions.push_back("5.如何指定特定时间段排班？");
    questions.push_back("6.为什么我明明包含关键字，但还是显示请检查是否存在字段“xxxx”？");
    ui->setupUi(this);
    foreach (QString it, questions)
    {
        ui->listWidget->addItem(it);
    }
    initanswers();
}

QuestionWindow::~QuestionWindow()
{
    delete ui;
}

void QuestionWindow::initanswers()
{
    answers.push_back("1.将xxxx.csv改为xxxx.txt;\n2.打开xxxx.txt文件查看右下角编码是否为UTF-8;\n3.若不是则选择另存为，编码选择UTF-8后保存;\n4.可以不修改后缀为csv直接上传也可。");
    answers.push_back("1.检查时间段数量一栏是否与表格一致;\n2.打开xxxx.csv文件查看;\n3.修改正确后即可重新生成。");
    answers.push_back("1.没有点击修改数量按钮;\n2.点击按钮后重新生成即可。");
    answers.push_back("1.更改网页编码即可;\n\n[Microsoft edge] 右上角三点->设置->默认浏览器"
                      "->允许在 Internet Explorer 模式下重新加载网站 (IE 模式)设置为允许->点击重启->回到保存的信息日志界面->右上角三点->"
                      "在Internet Explorer模式下重新加载->右击页面->编码->简体中文(GB2312)。\n\n"
                      "[QQ浏览器] 右击页面->编码->中文(简体)(GBK) / 中文(简体)(gb18030)。\n\n"
                      "[其他浏览器] 按对应浏览器更改编码的方法操作即可。");
    answers.push_back("1.当前程序没有此功能;\n2.可通过在原始表格删除对应时间段所有数据即可达到该目的。");
    answers.push_back("1.将xxxx.csv改为xxxx.txt;\n2.打开xxxx.txt文件查看右下角编码是否为UTF-8;\n3.若不是则选择另存为，编码选择UTF-8后保存;\n4.可以不修改后缀为csv直接上传也可。");
}

void QuestionWindow::on_searchBT_clicked()
{
    QString search = ui->searchEdit->text();
    ui->listWidget->clear();
    foreach (QString it, questions)
    {
        if(it.contains(search))
            ui->listWidget->addItem(it);
    }
}

void QuestionWindow::on_returnBT_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->stackedWidget->widget(0));
}


void QuestionWindow::on_listWidget_itemClicked(QListWidgetItem *item)
{
    QString text = item->text();
    QString seqtext;
    while (!text.startsWith('.'))
    {
        seqtext.append(text[0]);
        text.remove(0,1);
    }
    text.remove(0,1);
    ui->stackedWidget->setCurrentWidget(ui->stackedWidget->widget(1));
    ui->lineEdit->setText(text);
    ui->textEdit->setText(answers[seqtext.toInt()-1]);
}

